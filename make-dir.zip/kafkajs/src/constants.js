const EARLIEST_OFFSET = -2
const LATEST_OFFSET = -1
const INT_32_MAX_VALUE = Math.pow(2, 31) - 1

module.exports = {
  EARLIEST_OFFSET,
  LATEST_OFFSET,
  INT_32_MAX_VALUE,
}
