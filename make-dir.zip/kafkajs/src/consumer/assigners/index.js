const roundRobin = require('./roundRobinAssigner')

module.exports = {
  roundRobin,
}
