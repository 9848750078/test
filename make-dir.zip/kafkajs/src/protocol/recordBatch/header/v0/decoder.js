module.exports = decoder => ({
  key: decoder.readVarIntString(),
  value: decoder.readVarIntBytes(),
})
