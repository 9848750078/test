const murmur2 = require('./murmur2')
const createDefaultPartitioner = require('../legacy/partitioner')

module.exports = createDefaultPartitioner(murmur2)
