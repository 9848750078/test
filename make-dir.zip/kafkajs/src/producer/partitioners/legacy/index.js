const murmur2 = require('./murmur2')
const createLegacyPartitioner = require('./partitioner')

module.exports = createLegacyPartitioner(murmur2)
