module.exports = require('./lib/index.js')
