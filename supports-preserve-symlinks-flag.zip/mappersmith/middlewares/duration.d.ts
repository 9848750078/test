export { default } from "../middleware/duration";
