export declare const clone: <T>(obj: T) => T;
