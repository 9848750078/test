export declare const isTimeoutError: (e: Error) => boolean;
export declare const createTimeoutError: (message: string) => Error;
