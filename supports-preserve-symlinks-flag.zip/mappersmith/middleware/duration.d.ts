import type { Middleware } from './index';
/**
 * Adds started_at, ended_at and duration headers to the response
 */
export declare const DurationMiddleware: Middleware;
export default DurationMiddleware;
