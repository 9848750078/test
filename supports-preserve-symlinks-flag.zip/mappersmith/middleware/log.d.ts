import type { Middleware } from './index';
export declare const defaultSuccessLogger: (message: string) => void;
export declare const defaultErrorLogger: (message: string) => void;
export declare const setSuccessLogger: (logger: (message: string) => void) => void;
export declare const setErrorLogger: (logger: (message: string) => void) => void;
export declare const setLoggerEnabled: (value: boolean) => void;
/**
 * Log all requests and responses.
 */
export declare const LogMiddleware: Middleware;
export default LogMiddleware;
