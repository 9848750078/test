// @deprecated: Version 1 of retry is deprecated and should not be used anymore
import type { Middleware } from '../../index'
import type { RetryMiddlewareOptions } from '../v2/index'

/**
 * @deprecated: Version 1 of retry is deprecated and should not be used anymore
 */
declare const RetryMiddleware: Middleware
export default RetryMiddleware

/**
 * @deprecated: Version 1 of retry is deprecated and should not be used anymore
 */
declare const setRetryConfigs: (configs: Partial<RetryMiddlewareOptions>) => void

/**
 * @deprecated: Version 1 of retry is deprecated and should not be used anymore
 */
declare const calculateExponentialRetryTime: (retryTime: number) => number

export { setRetryConfigs, calculateExponentialRetryTime }
