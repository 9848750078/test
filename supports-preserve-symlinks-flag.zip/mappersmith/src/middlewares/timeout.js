export { default } from '../middleware/timeout'
