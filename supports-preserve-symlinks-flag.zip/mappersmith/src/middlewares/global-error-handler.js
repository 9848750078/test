export { default, setErrorHandler } from '../middleware/global-error-handler'
