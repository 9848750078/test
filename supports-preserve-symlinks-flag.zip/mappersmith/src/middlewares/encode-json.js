export { default, CONTENT_TYPE_JSON } from '../middleware/encode-json'
