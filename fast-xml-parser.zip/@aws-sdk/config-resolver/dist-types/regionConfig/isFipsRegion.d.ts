export declare const isFipsRegion: (region: string) => boolean;
