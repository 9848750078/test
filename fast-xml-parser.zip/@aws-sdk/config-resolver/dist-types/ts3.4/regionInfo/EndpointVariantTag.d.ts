export declare type EndpointVariantTag = "fips" | "dualstack";
