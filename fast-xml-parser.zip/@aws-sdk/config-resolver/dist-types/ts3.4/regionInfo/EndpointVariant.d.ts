import { EndpointVariantTag } from "./EndpointVariantTag";
export declare type EndpointVariant = {
  hostname: string;
  tags: EndpointVariantTag[];
};
