import { RuleSetObject } from "@aws-sdk/util-endpoints";
export declare const ruleSet: RuleSetObject;
