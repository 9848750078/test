export * from "./STS";
export * from "./STSClient";
export * from "./commands";
export * from "./defaultRoleAssumers";
export * from "./models";
export { STSServiceException } from "./models/STSServiceException";
