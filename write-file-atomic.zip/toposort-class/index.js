module.exports = require( './build/toposort.js' );
